package session1.after.two;

public interface Stopable {
	void stop();
}
