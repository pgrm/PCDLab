package session1.after.three;

public interface Stopable {
	void stop();
}
