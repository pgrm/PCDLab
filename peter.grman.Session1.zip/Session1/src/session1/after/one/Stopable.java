package session1.after.one;

public interface Stopable {
	void stop();
}
