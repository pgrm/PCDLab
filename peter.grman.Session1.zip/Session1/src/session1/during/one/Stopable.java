package session1.during.one;

public interface Stopable {
	void stop();
}
