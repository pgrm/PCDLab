package session1.during.two;

public interface Stopable {
	void stop();
}
