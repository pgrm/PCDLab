package session2;

public interface Stopable {
	void stop();
}
